import React from 'react';
import { useSelector } from 'react-redux';
import './HomePage.css'; // Custom CSS for HomePage styling

const HomePage = () => {
  const username = useSelector((state) => state.username);

  return (
    <div className="home-container">
      <div className="greeting-section">
        <h2>Welcome to the Dashboard</h2>
        <div className="username-display">
          <p className="welcome-message">Hello, {username ? username : 'Guest'}!</p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
