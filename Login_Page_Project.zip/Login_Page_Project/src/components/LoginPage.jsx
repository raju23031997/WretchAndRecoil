import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { updateField } from '../redux/actions';
import InputField from './InputField';
import './LoginPage.css'; // Custom CSS for styling
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({});

  const fields = [
    { name: 'username', label: 'Username', type: 'text' },
    { name: 'password', label: 'Password', type: 'password' },
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if(!formData.username || !formData.password){
      alert("Please enter userName & password");
    } else {
      dispatch(updateField('username', formData.username));
      dispatch(updateField('password', formData.password));
      navigate("/home");
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        {fields.map((field) => (
          <InputField
            key={field.name}
            label={field.label}
            type={field.type}
            name={field.name}
            value={formData[field.name] || ''}
            onChange={handleInputChange}
          />
        ))}
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default LoginPage;

