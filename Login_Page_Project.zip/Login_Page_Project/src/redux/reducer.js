import { UPDATE_FIELD } from './actions';

const initialState = {};

const loginReducer = (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_FIELD:
      return { ...state, [action.payload.fieldName]: action.payload.value };
    default:
      return state;
  }
};

export default loginReducer;

