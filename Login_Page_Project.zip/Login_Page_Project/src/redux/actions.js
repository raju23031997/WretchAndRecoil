export const UPDATE_FIELD = 'UPDATE_FIELD';

export const updateField = (fieldName, value) => ({
  type: UPDATE_FIELD,
  payload: { fieldName, value }
});
