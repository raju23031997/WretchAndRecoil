import { useSelector } from "react-redux";

const Home = () => {
  const username = useSelector((state) => state.auth.username);
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  return (
    <>
      {isAuthenticated && (
        <>
          <h2>Welcome, {username}</h2>
        </>
      )}
    </>
  );
};

export default Home;
